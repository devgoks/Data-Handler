<?php
return [
    'adminEmail' => 'admin@example.com',
    'supportEmail' => 'wondemorpayment@gmail.com',
    'user.passwordResetTokenExpire' => 3600,
];
