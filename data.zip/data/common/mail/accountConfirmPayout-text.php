<?php
use frontend\models\Payout;

/* @var $this yii\web\View */
/* @var $user common\models\User */
$user=Payout::find()->where(['id'=>$payout_id])->one();

$approveLink = Yii::$app->urlManager->createAbsoluteUrl(['site/confirm-payout', 'token' => $user->confirm_token]);
?>

Hello <?= Yii::$app->user->identity->username?>,

Follow the link below to approve your payout request:

<?= $approveLink ?>
