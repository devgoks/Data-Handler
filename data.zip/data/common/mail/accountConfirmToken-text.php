<?php

/* @var $this yii\web\View */
/* @var $user common\models\User */

$confirmLink = Yii::$app->urlManager->createAbsoluteUrl(['site/confirm-account', 'token' => $user->account_confirm_token]);
?>
Hello <?= $user->username ?>,

Follow the link below to reset your password:

<?= $confirmLink ?>
