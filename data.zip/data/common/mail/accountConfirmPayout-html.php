<?php
use yii\helpers\Html;
use frontend\models\Payout;
/* @var $this yii\web\View */
/* @var $user common\models\User */
$user=Payout::find()->where(['id'=>$payout_id])->one();

$approveLink = Yii::$app->urlManager->createAbsoluteUrl(['site/confirm-payout', 'token' => $user->confirm_token]);
?>
<div class="confirm-payout">
    <p>Hello <?= Html::encode(Yii::$app->user->identity->username) ?>,</p>

    <p>Follow the link below to approve your payout request:</p>

    <p><?= Html::a(Html::encode($approveLink), $approveLink) ?></p>
</div>
