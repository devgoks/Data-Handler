<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel frontend\models\Subscriptionsearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Manage Customers';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="subscription-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

<!--    <p>-->
<!--        --><?php //// Html::a('Create Subscription', ['create'], ['class' => 'btn btn-button-C']) ?>
<!--    </p>-->


    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'id',
            'customer_name',
            'insurance_code',
            'amount',
            'insurance_type',
            //'customer_id',
            //'company_id',
            //'company_name',
            //'agent_id',
            'agent_name',
            'status',
            //'created_at',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);?>


    <?php Pjax::end(); ?>
</div>
