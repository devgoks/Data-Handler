<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model frontend\models\Claims */

$this->title = $model->id;
$this->params['breadcrumbs'][] = ['label' => 'Claims', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="claims-view">
    <p>
        <?php if(Yii::$app->user->identity->account_type=="company"){
           echo Html::a('Approve Claim', ['approve', 'id' => $model->id,'option'=>'true'], ['class' => 'btn btn-button-C','data' => [
                'confirm' => 'Are you sure you want to Approve this claim?',
                'method' => 'post',
            ],]);
           echo"&nbsp;&nbsp&nbsp;&nbsp;&nbsp&nbsp;";
            echo Html::a('Disapprove Claim', ['approve', 'id' => $model->id,'option'=>'false'], ['class' => 'btn btn-button-C','data' => [
                'confirm' => 'Are you sure you want to disapprove this claim?',
                'method' => 'post',
            ],]);
        }  ?>
        <?php /*Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) */?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
           // 'id',
            'description',
            'claim_reference',
           // 'customer_id',
            'customer_name',
            'customer_phone',
            'status',
            // 'company_id',
            'company_name',
            'company_phone',
           // 'agent_id',
            'agent_name',
            'agent_phone',
            'agent_description',
            [
                    'attribute'=>'Image Uploaded',
                    'value'=>"../".$model->upload,
                    'format'=>['image',['width'=>'500','height'=>'500']],
            ],
            'created_at',
        ],
    ]) ?>

</div>
