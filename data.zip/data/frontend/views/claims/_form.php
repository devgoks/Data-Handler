<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\User;

/* @var $this yii\web\View */
/* @var $model frontend\models\Claims */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="claims-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'company_name')->dropDownList(
        ArrayHelper::map(User::find()->where ("account_type='company'")->all(),'id','username'),[
        ]
    ); ?>

    <?= $form->field($model, 'description')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'upload')->fileInput() ?>

    <div class="form-group">
        <?= Html::submitButton('Save', ['class' => 'btn btn-button-D']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
