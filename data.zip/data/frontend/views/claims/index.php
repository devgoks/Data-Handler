<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel frontend\models\Claimssearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Claims';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="claims-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?php
    if(Yii::$app->user->identity->account_type=="customer") { ?>
    <p>
        <?= Html::a('Make A Claim', ['create'], ['class' => 'btn btn-button-D']) ?>
    </p>


        <?php    echo GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],

               // 'id',
                'description',
                'claim_reference',
                //'customer_id',
                //'customer_name',
                //'customer_phone',
                //'company_id',
                'company_name',
                'company_phone',
                //'agent_id',
                //'agent_name',
                //'agent_phone',
                //'agent_description',
                //'upload',
                //'status',
                //'created_at',

                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]);
    }else{
        echo GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],

                //'id',
                'description',
                'claim_reference',
                //'customer_id',
                'customer_name',
                'customer_phone',
                //'company_id',
                //'company_name',
                //'company_phone',
                //'agent_id',
                //'agent_name',
                //'agent_phone',
                //'agent_description',
                //'upload',
                //'status',
                //'created_at',

                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]);
    }?>
</div>
