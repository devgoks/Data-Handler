-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2019 at 04:13 AM
-- Server version: 5.6.37
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `talentoceanonline`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `type` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `account_reference` varchar(255) NOT NULL,
  `amount` bigint(20) NOT NULL,
  `payout` bigint(20) NOT NULL,
  `days` int(255) NOT NULL,
  `date_opened` datetime NOT NULL,
  `date_due` datetime NOT NULL,
  `status` varchar(1000) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `user_id`, `type`, `description`, `account_reference`, `amount`, `payout`, `days`, `date_opened`, `date_due`, `status`) VALUES
(1, 1, 'land', '5,000,000 to 10,900,000 Naira', 'Z1EXRRrXA0', 6000000, 9900000, 27, '2018-06-01 10:10:41', '2018-06-19 10:10:41', 'active'),
(2, 1, 'shortterm', '200,000 to 4,900,000 Naira', 'H5SpzWiFSb', 280000, 448000, 27, '2018-06-06 10:12:33', '2018-07-24 10:12:33', 'paid'),
(3, 1, 'housing', '250,000 to 2,000,000 Naira', '1oAEiBu48P', 300000, 900000, 95, '2018-06-27 10:20:46', '2018-09-30 10:20:46', 'closed'),
(4, 1, 'longterm', '250,000 to 2,000,000 Naira', 'DOG9R3crbU', 400000, 1200000, 95, '2018-06-27 10:23:33', '2018-09-30 10:23:33', 'closed'),
(5, 1, 'shortterm', '200,000 to 4,900,000 Naira', 'eEBnRz999G', 500000, 800000, 27, '2018-06-27 10:24:55', '2018-07-24 10:24:55', 'closed'),
(6, 1, 'housing', '200,000 to 4,900,000 Naira', '6qFUaPYkUa', 270000, 432000, 27, '2018-06-27 02:48:41', '2018-07-24 02:48:41', 'paid'),
(7, 1, 'housing', '200,000 to 4,900,000 Naira', 'exBvGqgD7S', 1000000, 1600000, 27, '2018-06-27 03:40:48', '2018-07-24 03:40:48', 'paid'),
(8, 1, 'housing', '200,000 to 4,900,000 Naira', 'CK2kD0PSd4', 240000, 384000, 27, '2018-06-27 03:43:55', '2018-07-24 03:43:55', 'closed'),
(9, 1, 'longterm', '250,000 to 2,000,000 Naira', 'mwON60hZgd', 260000, 780000, 95, '2018-06-28 10:47:53', '2018-10-01 10:47:53', 'inactive'),
(10, 1, 'housing', '200,000 to 4,900,000 Naira', 'ah1GLLtQaR', 300000, 480000, 27, '2018-06-28 09:21:05', '2018-07-25 09:21:05', 'paid'),
(11, 1, 'housing', '200,000 to 4,900,000 Naira', 'l3cGCY1DdR', 235000, 376000, 27, '2018-06-28 09:28:28', '2018-07-25 09:28:28', 'closed'),
(12, 1, 'longterm', '3,000,000 to 10,000,000 Naira', 'qJoEPJoM2B', 3000000, 12000000, 125, '2018-06-29 01:12:51', '2018-11-01 01:12:51', 'active'),
(13, 1, 'housing', '200,000 to 4,900,000 Naira', 'PFQ1HKgNsX', 500000, 800000, 27, '2018-06-29 01:13:34', '2018-07-26 01:13:34', 'paid'),
(14, 1, 'housing', '200,000 to 4,900,000 Naira', '3HrFAAvVHP', 260000, 416000, 27, '2018-06-30 06:49:39', '2018-07-27 06:49:39', 'paid'),
(15, 1, 'housing', '200,000 to 4,900,000 Naira', 'ML5nXLv051', 230000, 368000, 27, '2018-07-07 02:57:08', '2018-08-03 02:57:08', 'paid'),
(16, 3, 'housing', '200,000 to 4,900,000 Naira', 'MTtzbnW6lh', 220000, 352000, 27, '2018-07-07 04:29:39', '2018-08-03 04:29:39', 'active'),
(17, 1, 'flight', '200,000 to 4,900,000 Naira', 'rv4BSFykK4', 2600000, 4160000, 27, '2018-07-16 11:45:57', '2018-08-12 11:45:57', 'inactive'),
(18, 1, 'education', '200,000 to 4,900,000 Naira', 'mcBSj35gtz', 210000, 336000, 27, '2018-07-16 11:51:28', '2018-08-12 11:51:28', 'paid');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE IF NOT EXISTS `bank` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(255) NOT NULL,
  `bank_code` varchar(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `bank_name`, `bank_code`) VALUES
(1, 'Access Bank', '044'),
(2, 'ALAT by WEMA', '035A'),
(3, 'Citibank Nigeria', '023'),
(4, 'Diamond Bank', '063'),
(5, 'Ecobank Nigeria', '050'),
(6, 'Enterprise Bank', '084'),
(7, 'Fidelity Bank', '070'),
(8, 'First Bank of Nigeria', '011'),
(9, 'First City Monument Bank', '214'),
(10, 'Guaranty Trust Bank', '058'),
(11, 'Heritage Bank', '030'),
(12, 'Jaiz Bank', '301'),
(13, 'Keystone Bank', '082'),
(14, 'MainStreet Bank', '014'),
(15, 'Parallex Bank', '526'),
(16, 'Providus Bank', '101'),
(17, 'Skye Bank', '076'),
(18, 'Stanbic IBTC Bank', '221'),
(19, 'Standard Chartered Bank', '068'),
(20, 'Sterling Bank', '232'),
(21, 'Suntrust Bank', '100'),
(22, 'Union Bank of Nigeria', '032'),
(23, 'United Bank For Africa', '033'),
(24, 'Unity Bank', '215'),
(25, 'Wema Bank', '035'),
(26, 'Zenith Bank', '057');

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `time` int(10) unsigned DEFAULT NULL,
  `rfc822` varchar(50) DEFAULT NULL,
  `sent_from` varchar(255) DEFAULT NULL,
  `sent_to` varchar(255) DEFAULT NULL,
  `message` text,
  `seen` int(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `chat`
--

INSERT INTO `chat` (`id`, `user_id`, `time`, `rfc822`, `sent_from`, `sent_to`, `message`, `seen`) VALUES
(1, 3, 1541195082, 'Fri, 02 Nov 18 21:44:42 +0000', 'olamigoke olabampe', 'support', 'Great Platform guys. Nice work.', 1),
(2, 3, 1541212081, 'Sat, 03 Nov 18 02:28:01 +0000', 'support', 'olamigoke olabampe', 'Thanks for the feedback.', 1),
(3, 3, 1561152547, 'Fri, 21 Jun 19 21:29:07 +0000', 'olamigoke olabampe', 'support', 'interesting', NULL),
(4, 3, 1561152570, 'Fri, 21 Jun 19 21:29:30 +0000', 'olamigoke olabampe', 'support', 'I will love to improve this', NULL),
(5, 7, 1561183469, 'Sat, 22 Jun 19 06:04:29 +0000', 'zinor waste manager', 'support', 'Hi Admin ,\r\nI am currently enjoying the platform thanks', 1),
(6, 7, 1561287086, 'Sun, 23 Jun 19 10:51:26 +0000', 'zinor waste manager', 'support', 'funny you', 1),
(7, 7, 1561287099, 'Sun, 23 Jun 19 10:51:39 +0000', 'zinor waste manager', 'support', 'interesting\r\n', 1),
(8, 7, 1561287115, 'Sun, 23 Jun 19 10:51:55 +0000', 'zinor waste manager', 'support', 'wonderful', 1),
(9, 7, 1561287161, 'Sun, 23 Jun 19 10:52:41 +0000', 'support', 'zinor waste manager', 'Great thanks', 0),
(10, 32, 1564277187, 'Sun, 28 Jul 19 01:26:27 +0000', 'AXA Mansard', 'support', 'jbuvc hj', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `claims`
--

CREATE TABLE IF NOT EXISTS `claims` (
  `id` int(255) NOT NULL,
  `description` varchar(10000) DEFAULT NULL,
  `claim_reference` varchar(255) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(255) DEFAULT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `company_phone` varchar(255) DEFAULT NULL,
  `agent_id` varchar(255) DEFAULT NULL,
  `agent_name` varchar(255) DEFAULT NULL,
  `agent_phone` varchar(255) DEFAULT NULL,
  `agent_description` varchar(255) DEFAULT NULL,
  `upload` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `claims`
--

INSERT INTO `claims` (`id`, `description`, `claim_reference`, `customer_id`, `customer_name`, `customer_phone`, `company_id`, `company_name`, `company_phone`, `agent_id`, `agent_name`, `agent_phone`, `agent_description`, `upload`, `status`, `created_at`) VALUES
(1, 'I had an accident. My car is badly damaged . ', 'Hvz6fOG4', '31', 'Nnaemeka Valentine', '+2349097611992', '32', 'AXA Mansard', '+2348091760117', NULL, NULL, NULL, NULL, 'uploads/insurgator-side123677.jpg', 'approved', '2019-07-28 07:37:37'),
(2, 'I had an accident. My car is badly damaged . ', 'Hvz6fOG4', '31', 'Nnaemeka Valentine', '+2349097611992', '33', 'Leadway', '+2348091760117', NULL, NULL, NULL, NULL, 'uploads/insurgator-side123677.jpg', 'approved', '2019-07-28 07:37:37'),
(3, 'My car was damaged in an accident today.', 'ZIjLWQ0W', '31', 'James Eziamaka', '+2349097611992', '33', 'Leadway', '+2348132331337', NULL, NULL, NULL, NULL, 'uploads/downloadIsur24083.jpg', 'disapproved', '2019-07-28 16:52:31'),
(4, 'My car was damaged in an accident today.', '6iN0U8hG', '31', 'James Eziamaka', '+2349097611992', '33', 'Leadway', '+2348132331337', NULL, NULL, NULL, NULL, 'uploads/downloadInsur20102.jpg', 'processing', '2019-07-28 17:40:17'),
(5, 'My car was damaged in an accident today.', 'vuKH0pqF', '31', 'James Eziamaka', '+2349097611992', '33', 'Leadway', '+2348132331337', NULL, NULL, NULL, NULL, 'uploads/9c4ec7f483d251d4929fde9e272ed7e721595.jpg', 'processing', '2019-08-15 15:14:32');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE IF NOT EXISTS `feedback` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `reviewer_id` int(255) NOT NULL,
  `description` varchar(5000) NOT NULL,
  `rating` varchar(255) NOT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `user_id`, `reviewer_id`, `description`, `rating`, `created_at`, `updated_at`) VALUES
(2, 41, 36, 'You have a great profile but work on adding other links that support your field like stackover and hacker rank e.t.c', '6', 1576555553, 1576555553),
(3, 3, 36, 'You have a great profile but work on adding other links that support your field like stackover and hacker rank e.t.c', '6', 1576555650, 1576555650);

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE IF NOT EXISTS `jobs` (
  `id` int(255) NOT NULL,
  `job_description` varchar(255) DEFAULT NULL,
  `job_type` varchar(255) DEFAULT NULL,
  `job_location` varchar(255) DEFAULT NULL,
  `job_id` varchar(255) DEFAULT NULL,
  `posted_by` varchar(255) DEFAULT NULL,
  `assigned_to` varchar(255) DEFAULT 'unassigned',
  `status` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `job_description`, `job_type`, `job_location`, `job_id`, `posted_by`, `assigned_to`, `status`, `created_at`) VALUES
(8, 'I need to dispose two dust bins', 'One Time Waste Disposal', 'Ogburu road delta state', '8t8B5he', '+2348126351314', 'unassigned', 'pending', '2019-06-22 12:40:03'),
(7, 'I need to dispose four dust bins', 'Recurring Waste Disposal', 'Ogburu road delta state', 'RjTrr1V', '+2348126351314', 'unassigned', 'pending', '2019-06-22 08:34:15'),
(6, 'I need to dispose two dust bins', 'One Time Waste Disposal', 'Ijapa road effurun delta state', 'HZxjw08', '+2348126351314', '+2348126351315', 'assigned', '2019-06-22 05:17:46');

-- --------------------------------------------------------

--
-- Table structure for table `mentor`
--

CREATE TABLE IF NOT EXISTS `mentor` (
  `id` int(255) NOT NULL,
  `mentee_id` int(255) NOT NULL,
  `mentor_name` varchar(255) NOT NULL,
  `mentor_email` varchar(255) NOT NULL,
  `mentor_id` int(255) NOT NULL,
  `mentee_name` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mentor`
--

INSERT INTO `mentor` (`id`, `mentee_id`, `mentor_name`, `mentor_email`, `mentor_id`, `mentee_name`, `status`, `created_at`, `updated_at`) VALUES
(1, 46, 'olamigoke olabampe', 'olabamsg@gmail.com', 3, 'Olatunji', 'ACCEPTED', 1576546296, 1576548114),
(2, 3, 'Olamide Falude', 'oulfai@gmail.com', 43, 'olamigoke olabampe', 'PENDING', 1576546443, 1576546443),
(3, 37, 'olamigoke olabampe', 'olabamsg@gmail.com', 3, 'Chidium Eze', 'PENDING', 1576546509, 1576546509),
(4, 47, 'olamigoke olabampe', 'olabamsg@gmail.com', 3, 'Tunde Majitofu', 'ACCEPTED', 1576546655, 1576549461),
(5, 3, 'Tunde Koladun', 'tundekola@gmail.com', 36, 'olamigoke olabampe', 'ACCEPTED', 1576546682, 1576549569);

-- --------------------------------------------------------

--
-- Table structure for table `merchant`
--

CREATE TABLE IF NOT EXISTS `merchant` (
  `id` int(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `auth_token` varchar(255) DEFAULT NULL,
  `webhook` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1528974385),
('m130524_201442_init', 1528974388);

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE IF NOT EXISTS `offers` (
  `id` int(255) NOT NULL,
  `offer_title` varchar(500) NOT NULL,
  `recruiter_id` int(255) NOT NULL,
  `recruiter_name` varchar(255) NOT NULL,
  `recruiter_email` varchar(255) NOT NULL,
  `talent_name` varchar(225) NOT NULL,
  `talent_id` int(255) NOT NULL,
  `description` varchar(10000) NOT NULL,
  `talent_email` varchar(255) NOT NULL,
  `talent_response` varchar(5000) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `offer_title`, `recruiter_id`, `recruiter_name`, `recruiter_email`, `talent_name`, `talent_id`, `description`, `talent_email`, `talent_response`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Backend Developer Job Offer From Google', 33, 'Leadway', 'leadway@gmail.com', 'olamigoke olabampe', 3, 'Back-end Developers Job Description Template\r\nWe are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills.\r\n\r\nTo succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated.\r\n\r\nBack-end Developer Responsibilities:\r\nCompile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement.\r\nCollaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience.\r\nDeveloping ideas for new programs, products, or features by monitoring industry developments and trends.\r\nRecording data and reporting it to proper parties, such as clients or leadership.\r\nParticipating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members.\r\nTaking lead on projects, as needed.\r\n\r\nPay : $50 per hour.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n', 'olabamsg@gmail.com', 'I am interested in your offer.', 'ACCEPTED', 1576200226, 1576202228),
(2, 'Java Spring Developer Role', 33, 'Leadway', 'leadway@gmail.com', 'olamigoke olabampe', 3, 'Back-end Developers Job Description Template We are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills. To succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated. Back-end Developer Responsibilities: Compile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement. Collaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience. Developing ideas for new programs, products, or features by monitoring industry developments and trends. Recording data and reporting it to proper parties, such as clients or leadership. Participating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members. Taking lead on projects, as needed. Pay : $50 per hour.', 'olabamsg@gmail.com', 'Thanks I appreciate the offer. But I am currently not willing to relocate to your country.', 'DECLINED', 1576411152, 1576555759),
(3, 'Andela Software Developer Role', 33, 'Leadway', 'leadway@gmail.com', 'olamigoke olabampe', 3, 'Back-end Developers Job Description Template We are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills. To succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated. Back-end Developer Responsibilities: Compile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement. Collaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience. Developing ideas for new programs, products, or features by monitoring industry developments and trends. Recording data and reporting it to proper parties, such as clients or leadership. Participating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members. Taking lead on projects, as needed. Pay : $50 per hour.', 'olabamsg@gmail.com', 'I will love to work at Andela. I like your culture and environment ,', 'ACCEPTED', 1576447201, 1576447430),
(4, 'DevOps With Leadway', 33, 'Leadway', 'leadway@gmail.com', 'Damilola Ojo', 39, 'DevOps Engineer Job Description Template We are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills. To succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated. Back-end Developer Responsibilities: Compile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement. Collaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience. Developing ideas for new programs, products, or features by monitoring industry developments and trends. Recording data and reporting it to proper parties, such as clients or leadership. Participating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members. Taking lead on projects, as needed. Pay : $50 per hour.', 'damioja@gmail.com', NULL, 'PENDING', 1576447286, 1576447286),
(5, 'Java Enterprise Developer', 33, 'Leadway', 'leadway@gmail.com', 'olamigoke olabampe', 3, 'Back-end Developers Job Description Template We are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills. To succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated. Back-end Developer Responsibilities: Compile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement. Collaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience. Developing ideas for new programs, products, or features by monitoring industry developments and trends. Recording data and reporting it to proper parties, such as clients or leadership. Participating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members. Taking lead on projects, as needed. Pay : $50 per hour.\r\nBack-end Developers Job Description Template We are looking for an analytical, results-driven Back-end Developer who will work with team members to troubleshoot and improve current back-end applications and processes. The Back-end Developer will use his or her understanding ofdolla programming languages and tools to analyze current codes and industry developments, formulate more efficient processes, solve problems, and create a more seamless experience for users. You should have excellent communication, computer, and project management skills. To succeed as a Backend Developer, you should be focused on building a better, more efficient program and creating a better end-user experience. You should be knowledgeable, collaborative, and motivated. Back-end Developer Responsibilities: Compile and analyze data, processes, and codes to troubleshoot problems and identify areas for improvement. Collaborating with the front-end developers and other team members to establish objectives and design more functional, cohesive codes to enhance the user experience. Developing ideas for new programs, products, or features by monitoring industry developments and trends. Recording data and reporting it to proper parties, such as clients or leadership. Participating in continuing education and training to remain current on best practices, learn new programming languages, and better assist other team members. Taking lead on projects, as needed. Pay : $50 per hour.', 'olabamsg@gmail.com', NULL, 'PENDING', 1576555902, 1576555902);

-- --------------------------------------------------------

--
-- Table structure for table `payment_page`
--

CREATE TABLE IF NOT EXISTS `payment_page` (
  `id` int(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `description` varchar(5000) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `page_id` varchar(255) DEFAULT NULL,
  `owner` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_page`
--

INSERT INTO `payment_page` (`id`, `phone`, `description`, `image`, `page_id`, `owner`, `status`, `created_at`) VALUES
(1, '+2348052240517', 'Peculair kiddies is a place ..........', NULL, 'NCJ36O', 'Peculair Kiddies Daycare', 'active', '2018-10-23 02:59:58'),
(8, '+2348091760116', 'Buy your free onions here', NULL, 'qJIoPE', 'Mama Nisi', 'active', '2018-10-24 11:39:54'),
(7, '+2348091760116', 'Pay Goke now here', NULL, 'e6J4YY', 'Goks Blog', 'active', '2018-10-24 03:47:52'),
(9, '+2348091760116', 'Pay for your good shoes here', NULL, 'Przq9Q', 'Emeka Shoe maker', 'active', '2018-10-24 11:41:28'),
(10, '+2348091760116', NULL, NULL, 'H0Ye6u', 'Goks Blog', 'active', '2018-10-24 12:44:19'),
(11, '+2348091760116', NULL, NULL, 'GbQPis', 'Good luck', 'active', '2018-10-24 12:55:49'),
(12, '+2348091760116', NULL, NULL, '8PnM73', 'Good luck', 'active', '2018-10-24 13:00:37');

-- --------------------------------------------------------

--
-- Table structure for table `payout`
--

CREATE TABLE IF NOT EXISTS `payout` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `status` varchar(255) DEFAULT NULL,
  `confirm_token` varchar(1000) DEFAULT NULL,
  `recipient_code` varchar(255) DEFAULT NULL,
  `amount` bigint(20) DEFAULT NULL,
  `request_time` datetime DEFAULT NULL,
  `paid_time` datetime DEFAULT NULL,
  `reference` varchar(255) NOT NULL,
  `account_reference` varchar(255) NOT NULL,
  `payout_attempt` int(255) DEFAULT NULL
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payout`
--

INSERT INTO `payout` (`id`, `user_id`, `status`, `confirm_token`, `recipient_code`, `amount`, `request_time`, `paid_time`, `reference`, `account_reference`, `payout_attempt`) VALUES
(20, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 210000, '2018-07-16 01:07:14', '2018-07-16 01:08:50', '46at78fo2r', 'mcBSj35gtz', 1),
(19, 1, 'processing', 'f6mXo9UlDA28mGR', 'RCP_fgho4ayxqsnl12u', 240000, '2018-07-06 05:00:45', NULL, 'fvxi0xf8j6', 'CK2kD0PSd4', NULL),
(18, 1, 'processing', '3v93kDlEI6utXQ2', 'RCP_fgho4ayxqsnl12u', 235000, '2018-07-06 05:00:03', NULL, '2mio8bxj6j', 'l3cGCY1DdR', NULL),
(17, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 500000, '2018-06-29 01:14:54', '2018-06-29 01:15:27', 'a9opjz5rym', 'PFQ1HKgNsX', 1),
(16, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 270000, '2018-06-28 12:31:21', '2018-06-28 12:31:56', 'zttoi8uzt0', '6qFUaPYkUa', 1),
(15, 1, 'processing', 'bgxythT4Cgof0VJ', 'RCP_fgho4ayxqsnl12u', 400000, '2018-06-28 12:16:35', NULL, 'udvvt04w77', 'DOG9R3crbU', NULL),
(21, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 230000, '2018-07-16 01:14:50', '2018-07-16 01:15:17', 'heghvrjmtm', 'ML5nXLv051', 1),
(22, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 230000, '2018-07-16 01:15:02', '2018-07-16 01:16:17', '8txmv92a1o', 'ML5nXLv051', 1),
(23, 1, 'processing', 'CCh61VPxIHJTdjO', 'RCP_fgho4ayxqsnl12u', 1000000, '2018-07-16 01:26:30', NULL, '8iy9ges77e', 'exBvGqgD7S', NULL),
(24, 1, 'approved', NULL, 'RCP_fgho4ayxqsnl12u', 1000000, '2018-07-16 01:26:33', NULL, 'wwk0agcdzu', 'exBvGqgD7S', NULL),
(25, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 1000000, '2018-07-16 01:27:45', '2018-07-16 01:28:02', 'jqe3im0bsu', 'exBvGqgD7S', 1),
(26, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 280000, '2018-07-16 01:39:50', '2018-07-16 01:44:45', 'kkct29d10z', 'H5SpzWiFSb', 1),
(27, 1, 'processing', 'USg6yeybXs9zkD3', 'RCP_fgho4ayxqsnl12u', 280000, '2018-07-16 01:39:55', NULL, 'gldi93kzbw', 'H5SpzWiFSb', NULL),
(28, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 260000, '2018-07-19 02:49:38', '2018-07-19 03:13:59', 'cpejh1xlem', '3HrFAAvVHP', 1),
(29, 1, 'paid', NULL, 'RCP_fgho4ayxqsnl12u', 300000, '2018-07-19 03:14:49', '2018-07-19 03:15:43', 'wxom28mhqd', 'ah1GLLtQaR', 1),
(30, 1, 'processing', 'LoNbNAopvZoVLxx', 'RCP_fgho4ayxqsnl12u', 300000, '2018-07-19 03:15:03', NULL, 'qvm7g3dnqp', 'ah1GLLtQaR', NULL),
(31, 1, 'approved', 'r2uSldCEC3SBIz9', 'RCP_fgho4ayxqsnl12u', 9900000, '2018-07-19 03:22:21', NULL, '2m8z9clzgt', 'Z1EXRRrXA0', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE IF NOT EXISTS `plans` (
  `id` int(255) NOT NULL,
  `amount_from` bigint(20) NOT NULL,
  `amount_to` bigint(20) NOT NULL,
  `description` varchar(255) NOT NULL,
  `rate` double NOT NULL,
  `days` int(255) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `plans`
--

INSERT INTO `plans` (`id`, `amount_from`, `amount_to`, `description`, `rate`, `days`) VALUES
(1, 200000, 4900000, '200,000 to 4,900,000 Naira', 0.6, 27),
(2, 5000000, 10900000, '5,000,000 to 10,900,000 Naira', 0.65, 27),
(3, 11000000, 15000000, '11,000,000 to 15,000,000 Naira', 0.7, 60),
(4, 250000, 2000000, '250,000 to 2,000,000 Naira', 2, 95),
(5, 3000000, 10000000, '3,000,000 to 10,000,000 Naira', 3, 125);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `code`, `description`, `amount`, `type`, `company_id`, `company_name`, `status`, `created_at`) VALUES
(1, 'EASY CARE', 'An affordable health plan with access to quality health care for you & your loved ones. Pay as low as N12,000  HEALTH PLANS Health Insurance Whatever your healthcare needs are, we have the perfect plan just for you   ', '12000', 'health', '32', 'AXA Mansard', 'active', '2019-07-28 03:13:02'),
(2, 'Hospital Cash', 'The Leadway Hospital Cash Plan Insurance is designed to provide a daily financial benefit for hospitalization arising from accidental injury or illness.\r\n\r\nAs long as you are under 65 years of age, you are eligible for the Hospital Cash Plan Insurance.', '7000', 'health', '33', 'Leadway', 'active', '2019-07-28 11:28:34'),
(3, 'Private Health', 'The Healthcare Cover is offered, arranged and coordinated through our associate company, Total Health Trust Limited. Benefits are defined and standardization of the medical care given is governed by managed care rules and contract.', '200000', 'health', '33', 'Leadway', 'active', '2019-07-28 11:29:47'),
(4, 'Pick and Pay', 'Comprehensive insurance on your precious car doesn’t have to be expensive anymore with the Leadway Pick and Pay Motor Insurance that offers you the opportunity to get a cover with ease.', '250000', 'car', '33', 'Leadway', 'active', '2019-07-28 11:48:08'),
(5, 'Personal Accident', 'The product offers comprehensive third party liability, including death of, or bodily injury to, third parties.', '500000', 'car', '33', 'Leadway', 'active', '2019-07-28 11:50:33'),
(6, 'Burglary - Damage', 'The Leadway Burglary Insurance policy is designed to protect you against loss or damage to property caused by a theft that involves the forcible and violent breaking  into  or  out of the premises.', '50000', 'property', '33', 'Leadway', 'active', '2019-07-28 11:52:21'),
(8, 'autoflex', 'AutoFlex is for privately used saloon cars and SUVs only', '200000', 'car', '32', 'AXA Mansard', 'active', '2019-07-28 13:00:27'),
(9, 'autoplus', 'A comprehensive motor insurance cover that will provide a courtesy car in the event of theft or accidental damage', '2000000', 'car', '32', 'AXA Mansard', 'active', '2019-07-28 13:01:53'),
(10, 'autogo', 'Get peace of mind with our quick and easy online third party motor insurance plan. AutoGo is designed to give you the basic features of third party motor insurance with no hassle.', '5000', 'car', '32', 'AXA Mansard', 'active', '2019-07-28 13:03:38'),
(11, 'Money Market', 'The AXA Mansard Money Market Mutual Fund is designed for investors with low risk appetite looking to maximize interest income in short-tenored securities. ', '50000', 'investment', '32', 'AXA Mansard', 'active', '2019-07-28 13:05:56');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `full_name` varchar(255) NOT NULL,
  `display_picture` varchar(255) DEFAULT NULL,
  `points` int(255) DEFAULT NULL,
  `job_preference` varchar(255) NOT NULL,
  `career_level` varchar(255) NOT NULL,
  `years_of_experience` varchar(255) DEFAULT NULL,
  `location` varchar(500) NOT NULL,
  `skills` varchar(5000) DEFAULT NULL,
  `cv_url` varchar(500) DEFAULT NULL,
  `linkedIn_url` varchar(500) DEFAULT NULL,
  `other_links` varchar(1000) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id`, `user_id`, `full_name`, `display_picture`, `points`, `job_preference`, `career_level`, `years_of_experience`, `location`, `skills`, `cv_url`, `linkedIn_url`, `other_links`, `status`, `created_at`, `updated_at`) VALUES
(1, 3, 'Olamigoke Olabampe', NULL, 711, 'Backend Developer', 'Junior', '2', 'Lagos, Nigeria', 'Java,Spring,MySql,Php,YII,Python,MSSql', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', 'https://www.github.com/devgoks', 'active', 1576190887, 1576555650),
(2, 34, 'Nnaemeka Eziamaka', NULL, 597, 'Backend Developer', 'Junior', '2', 'Lagos', 'Node.js, React, MongoDB, PostgreSQL , Express.js', '', '', '', 'active', 1576219651, 1576555353),
(3, 36, 'Tunde Koladun', NULL, 965, 'Frontend Developer', 'Intermediate', '3', 'Lagos, Nigeria', 'Angular,Html,css,react,vue,css3,bootstrap,webpack', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576352703, 1576352703),
(4, 37, 'Chidum Eze', NULL, 408, 'UX/UI Designer', 'Senior', '4', 'Abuja, Nigeria', 'Photoshop, Figma, Html, Css, Adobe, SketchPad', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576352875, 1576352875),
(5, 38, 'Damilola Badejo', NULL, 948, 'Frontend Developer', 'Junior', '2', 'Lagos, Nigeria', 'Angular,react,vue,bootstrap,webpack,Javascript', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576353310, 1576358033),
(6, 39, 'Damilola Ojo', NULL, 412, 'DevOps Engineer', 'Intern', '1', 'Kaduna,Nigeria', 'Docker,AWS,Mysql,Linux,Windows', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576356287, 1576356287),
(7, 40, 'Bola Ojalade', NULL, 318, 'Frontend Developer', 'Junior', '2', 'Lagos, Nigeria', 'Angular,Html,css,react,vuecss3,bootstrap', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576356356, 1576356356),
(8, 41, 'Elijah Abiluluja', NULL, 878, 'Product Manager', 'Intermediate', '3', 'Abuja, Nigeria', 'Jira,Taskflow,Scrum master,Project Planning', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576356502, 1576555553),
(9, 42, 'Elizabeth Jajalun', NULL, 433, 'Frontend Developer', 'Senior', '5', 'Lagos, Nigeria', 'Angular,React,Nodejs,HTML5', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576356605, 1576358167),
(10, 43, 'Olamide Falude', NULL, 994, 'Backend Developer', 'Junior', '3', 'Lagos, Nigeria', 'laravel,MySql,Php,YII,Python,MSSql', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576356805, 1576356805),
(11, 44, 'Deborah Ojo', NULL, 200, 'Mobile Application Developer', 'Entry Level', '1', 'Lagos, Nigeria', 'Java,Andriod,Xml', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576360877, 1576360877),
(12, 46, 'Olatunji Oguitade', NULL, 200, 'Frontend Developer', 'Intermediate', '3', 'Lagos, Nigeria', 'Angular,Html,css,react,vuecss3,bootstrap', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576451830, 1576451830),
(13, 47, 'Tunde Matijulade', NULL, 200, 'DevOps Engineer', 'Junior', '2', 'Abuja, Nigeria', 'Docker,aws,digital ocean,linux', 'https://drive.google.com/file/d/1WYmhcXisS0h8v-R5amL3AMENV_ryHRHl/view?usp=sharing', 'https://www.linkedin.com/in/olamigoke-olabampe/', '', 'active', 1576452047, 1576452047);

-- --------------------------------------------------------

--
-- Table structure for table `quotes`
--

CREATE TABLE IF NOT EXISTS `quotes` (
  `id` int(255) NOT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `insurance_type` varchar(255) DEFAULT NULL,
  `insurance_company` varchar(255) DEFAULT NULL,
  `insurance_company_id` varchar(255) DEFAULT NULL,
  `feedback` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `upload` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(255) NOT NULL,
  `job_id` varchar(255) DEFAULT NULL,
  `rating_value` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rating`
--

INSERT INTO `rating` (`id`, `job_id`, `rating_value`, `comment`, `created_at`) VALUES
(1, '8fSPCzM', '3', 'Service was great. Nice shoemaker', '2018-11-02 17:55:41'),
(2, '8fSPCzM	', '4', 'The bricklayer was nice and fast.', '2018-11-03 03:29:07'),
(3, 'RjTrr1V', '4', 'good ', '2019-06-22 12:43:26');

-- --------------------------------------------------------

--
-- Table structure for table `referral`
--

CREATE TABLE IF NOT EXISTS `referral` (
  `id` int(255) NOT NULL,
  `user_id` int(255) NOT NULL,
  `referral_name` varchar(255) NOT NULL,
  `created_at` int(20) DEFAULT NULL,
  `updated_at` int(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `referral`
--

INSERT INTO `referral` (`id`, `user_id`, `referral_name`, `created_at`, `updated_at`) VALUES
(1, 3, 'Tunde Majitofu', 1576451986, 1576451986);

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` int(255) NOT NULL,
  `insurance_type` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `submitted_by` varchar(255) DEFAULT NULL,
  `report_reference` varchar(255) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `claim_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `request`
--

CREATE TABLE IF NOT EXISTS `request` (
  `id` int(255) NOT NULL,
  `merchant_phone` varchar(255) DEFAULT NULL,
  `webhook` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `user_phone` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subscription`
--

CREATE TABLE IF NOT EXISTS `subscription` (
  `id` int(255) NOT NULL,
  `insurance_code` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `insurance_type` varchar(255) DEFAULT NULL,
  `customer_id` varchar(255) DEFAULT NULL,
  `customer_name` varchar(255) DEFAULT NULL,
  `company_id` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `agent_id` varchar(255) DEFAULT NULL,
  `agent_name` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subscription`
--

INSERT INTO `subscription` (`id`, `insurance_code`, `amount`, `insurance_type`, `customer_id`, `customer_name`, `company_id`, `company_name`, `agent_id`, `agent_name`, `status`, `created_at`) VALUES
(1, 'ol12ba34mp45', '5000', 'health', '31', 'Nnaemeka Valentine', '32', 'AXA Mansard', '', '', 'active', '2019-07-28 04:38:51'),
(2, 'ol12baytyty34mp45', '15000', 'agric', '31', 'Nnaemeka Valentine', '33', 'leadway', NULL, NULL, 'active', '2019-07-28 04:38:51'),
(4, 'ol12baytdjdjjd4mp45', '7500', 'car', '31', 'Nnaemeka Valentine', '33', 'leadway', NULL, NULL, 'active', '2019-07-28 04:38:51'),
(5, 'G1ZM8oIy4F', '200000', 'health', '31', 'James Eziamaka', '33', 'Leadway', NULL, NULL, 'active', '2019-07-28 14:27:29'),
(6, 'KGzpkSpfLL', '200000', 'health', '31', 'James Eziamaka', '33', 'Leadway', NULL, NULL, 'active', '2019-07-28 14:29:12'),
(7, 'RXZb5oMHRB', '2000000', 'car', '31', 'James Eziamaka', '32', 'AXA Mansard', NULL, NULL, 'active', '2019-07-28 14:43:05'),
(8, 'IhuHS7PaKv', '500000', 'car', '31', 'James Eziamaka', '33', 'Leadway', NULL, NULL, 'active', '2019-07-28 17:39:16'),
(9, 'b50nMJDMII', '2000000', 'car', '31', 'James Eziamaka', '32', 'AXA Mansard', NULL, NULL, 'active', '2019-08-15 15:22:38');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE IF NOT EXISTS `transaction` (
  `id` int(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `transaction_reference` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `amount` varchar(255) DEFAULT NULL,
  `transaction_from` varchar(255) DEFAULT NULL,
  `transaction_to` varchar(255) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `phone`, `transaction_reference`, `description`, `amount`, `transaction_from`, `transaction_to`, `type`, `status`, `created_at`) VALUES
(1, '+2348091760116', 'VsXp7gfr9z', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'pending', '2018-10-22 05:34:05'),
(2, '+23491760116', 'QCXUlkmkne', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2018-10-22 05:34:42'),
(3, '+2348052240517', 'VhqhiApMnC', 'funding my wallet from payment page', '50000', 'customers', 'your wallet', 'payment page', 'pending', '2018-10-23 12:21:14'),
(4, '+2348052240517', 'fR61D67jiy', 'funding my wallet from payment page', '50000', 'customers', 'your wallet', 'payment page', 'successful', '2018-10-23 12:21:24'),
(5, '+2348091760116', 'FYxN4em0KV', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'pending', '2018-10-24 03:45:26'),
(6, '+2348091760116', 'V9JStYnv4P', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'pending', '2018-10-24 03:48:39'),
(34, '+2348091760116', 'HmaBkSBo9D', 'funding my wallet from payment page', '5000', 'customers', 'your wallet', 'payment page', 'successful', '2018-10-24 13:01:03'),
(35, '+2348091760116', 'NhHbe4fkRA', 'funding my Cashbreeze purse', '300', 'your bank', 'your wallet', 'bank to purse', 'pending', '2018-11-03 01:03:23'),
(36, '+2348091760116', 'NW0JCXCOcg', 'Paying for car wash service', '2000', 'wallet', 'wallet', 'transfer', 'failed', '2018-11-03 04:42:55'),
(37, '+2348052240517', 'lXFekcoO7Y', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2018-11-03 09:33:15'),
(38, '+2348052240517', 'DK7iGvXSMs', 'funding my Cashbreeze purse', '300', 'your bank', 'your wallet', 'bank to purse', 'successful', '2018-11-03 09:39:59'),
(39, '+2348052240517', 'E8cBylcfca', 'funding my Cashbreeze purse', '300', 'your bank', 'your wallet', 'bank to purse', 'successful', '2018-11-03 09:41:36'),
(40, '+2348091760116', 'jesY5FY3ft', 'funds', '200', 'wallet', 'wallet', 'transfer', 'successful', '2019-06-22 01:33:11'),
(41, '+2348126351314', 'Qq0PZa0utU', 'funds', '200', 'wallet', 'wallet', 'transfer', 'failed', '2019-06-22 04:16:20'),
(42, '+2348126351314', '2znGsOO17p', 'funding my Cashbreeze purse', '2000', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 04:40:37'),
(43, '+2348126351314', 'hJzmxD4htu', 'funding my Cashbreeze purse', '2000', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 04:42:54'),
(44, '+2348126351314', 'YpB6HxDfGO', 'funding my Cashbreeze purse', '2350', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-06-22 04:57:31'),
(45, '+2348126351315', '6GalN6Xxeq', 'funding my Cashbreeze purse', '16040', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-06-22 05:16:56'),
(46, '+2348126351314', 'qE68bmba37', 'funding my Cashbreeze purse', '200', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 13:48:33'),
(47, '+2348126351314', 'ch4ZP804bV', 'funding my Cashbreeze purse', '200', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 13:49:12'),
(48, '+2348126351314', 'ANSrMc01oa', 'funding my Cashbreeze purse', '200', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 13:50:09'),
(49, '+2348126351314', 'jYEDrtJJPm', 'funding my Cashbreeze purse', '200', 'your bank', 'your wallet', 'bank to purse', 'pending', '2019-06-22 13:50:39'),
(50, '+2348091760117', 'nKItJs7aNb', 'funding my Cashbreeze purse', '4500', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-07-28 10:51:28'),
(51, '+2349097611992', '6q2wFe3w8B', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-07-28 12:33:17'),
(52, '+2349097611992', 'GXzEmkPVCC', 'funding my Cashbreeze purse', '1000000000 ', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-07-28 14:23:50'),
(53, '+2348132331337', 'rzxN4f1tkQ', 'funding my Cashbreeze purse', '5000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-07-28 16:38:14'),
(54, '+2348091760116', '7twvX4yoem', 'funds', '100', 'wallet', 'wallet', 'transfer', 'successful', '2019-12-12 01:40:04'),
(55, '+2348091760116', 'HrD3UaaVba', 'funding my Cashbreeze purse', '90', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-12-12 01:40:46'),
(56, '+2348091760116', 'kydJkeUE7N', 'funding my Cashbreeze purse', '7000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-12-12 01:40:57'),
(57, '+2348091760116', 'Y6GpOPZy1z', 'funding my Cashbreeze purse', '7000', 'your bank', 'your wallet', 'bank to purse', 'successful', '2019-12-12 01:41:07');

-- --------------------------------------------------------

--
-- Table structure for table `uploads`
--

CREATE TABLE IF NOT EXISTS `uploads` (
  `id` int(255) NOT NULL,
  `reference_id` varchar(255) DEFAULT NULL,
  `upload_path` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_confirm_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `address` varchar(1500) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_number` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `passport` varchar(10000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `recipient_code` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` smallint(6) DEFAULT '10',
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `bvn` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `purse` varchar(255) COLLATE utf8_unicode_ci DEFAULT '0',
  `pin` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone_confirm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email_confirm` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_big_merchant` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fingerprint` varbinary(4000) DEFAULT NULL,
  `education_level` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `account_type` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_agent` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `account_confirm_token`, `password_reset_token`, `email`, `address`, `dob`, `bank_name`, `account_name`, `account_number`, `passport`, `recipient_code`, `status`, `created_at`, `updated_at`, `phone`, `bvn`, `purse`, `pin`, `phone_confirm`, `email_confirm`, `is_big_merchant`, `fingerprint`, `education_level`, `account_type`, `is_agent`) VALUES
(3, 'olamigoke olabampe', '3xL1RUpQ5QcxEsAL-KxtICyr3u4DC1Nk', '$2y$13$Y1l7YFjbAtblv80ii0scPOFMSmeRbKAw/W6rpeuo1iImPG0IbRFyO', NULL, NULL, 'olabamsg@gmail.com', 'blk 78 Agungi, lekki epe expressway road', NULL, '044', 'Olabampe Valentine', '2100074589', NULL, NULL, 10, 1541171272, 1576111267, '+2348091760116', '1234876811', '21890', '123456', NULL, NULL, NULL, NULL, NULL, 'talent', 'true'),
(4, 'Olayinka Adebisi', '8eMSPKuOllWFvqj9Dn5dWyM88LqErKEy', '$2y$13$Ezy0RTY3ZW.4kztnGzvd8uGsEpzwWQyiHH9AO00LZgS/S/lXTLJ3u', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1541177875, 1561163591, '+2348052240517', NULL, '5800', '123456', NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(5, 'Olamide Olabampe', '_oWHfn9Lx6xWKod7nVEIWquj9RdSAmOK', '$2y$13$RT.rL0ifly53ptecfv2gkejsbaxvQJeUE4KwpQzdtmBcrTpjpRlo6', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1541188767, 1541188767, '+2348091760111', NULL, '0', '123456', NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(6, 'Oghoro Bob', 'mtnx32k9LBUDVDBSgeq7efEMg_KoWR5q', '$2y$13$Y1l7YFjbAtblv80ii0scPOFMSmeRbKAw/W6rpeuo1iImPG0IbRFyO', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1561172646, 1561175876, '+2348126351314', NULL, '2350', '123456', NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(31, 'James Eziamaka', 'TXVQ5geuXisxHbcOD4XtExGS-BT_5unT', '$2y$13$0yjDVuKSWeIVvUYRohXhiu4OrsC8M95M7IYI/.7IuxaHBb/.pRS7i', NULL, NULL, 'eziamakanv@gmail.com', 'blk 78 Agungi, lekki epe expressway road', NULL, '023', 'Nnaemeka Valentine', '2100074589', NULL, NULL, 10, 1564258926, 1565878958, '+2349097611992', '1234876809', '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', 'true'),
(32, 'AXA Mansard', 'SzB5U4FXMWxZT0rVP-E9C_lF2MhbOhVY', '$2y$13$6wEOEetUtqC4xPVmlXrrEu73FyQ78CDptofQhju3O1WJt4u6phlES', NULL, NULL, 'axainfo@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1564272340, 1565878958, '+2348091760117', NULL, '4004500', NULL, NULL, NULL, NULL, NULL, NULL, 'recruiter', NULL),
(33, 'Leadway', 'pY3L9luENRNAkZxadcgltyqx_3Y1REIF', '$2y$13$516vlNM4P7N.lyEnN0PFGe22Jnpk3EN./aNf6ks/tMloiu9s1rmca', NULL, NULL, 'leadway@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1564309353, 1564331956, '+2348132331337', NULL, '905000', NULL, NULL, NULL, NULL, NULL, NULL, 'recruiter', NULL),
(34, 'Mekus1', 'deC10hB-rzA4Os2IeSg9-CMugWlJ8Cba', '$2y$13$OWRfKsrqfPp04mdKPS47TewfnA4lk5DmsKBH/G5kMFaGwnGjgyMhO', NULL, NULL, 'emekaeziamaka@icloud.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576219553, 1576219553, '08111111111', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(35, 'Test Company', 'l0oAbXrkoWH3Eo3CSUe5RA4NeLoiidVV', '$2y$13$6qTbwK0cyEO/Gm9RglBYWuUdkxKTguNohJwf5aXTbXSRNew.9roBm', NULL, NULL, 'olabamsg977@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576322126, 1576322126, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'recruiter', NULL),
(36, 'Tunde Koladun', 'RZRgPx1JcnxxgdZal-6OUrRY1peOHpZ1', '$2y$13$SI2PGstQtohP.EFMqtq4MuAcoMPpXsSzaKMjKbqS21Bye9TLzXFse', NULL, NULL, 'tundekola@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576352595, 1576352595, '08023460216', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(37, 'Chidium Eze', 'a0OGRZE0ENNpVUnhhtQoXDEMz769XPDS', '$2y$13$ybQHD6Z4HnvoyRODfAeVAuZv8hR/M2lgo39TkiLNDpYAEQdSxGkSa', NULL, NULL, 'chieze@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576352767, 1576352767, '08091762312', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(38, 'Damilola Badejo', '0ydGqcG8F_IePSlVovzoWa06_l1tu84m', '$2y$13$4xeaWVVIfRf3KsVWrSXjUORlnkybdSFALvegm6Z7vgv9EIXy7V4CK', NULL, NULL, 'damibade@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576353254, 1576353254, '08060197116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(39, 'Damilola Ojo', 'ba1yvgoKD-hV4ZLzxg3wHZemYArgL_r9', '$2y$13$FOv2WVL/fv1drcQZ/C/COe/9A1fZiT.zyYFBznrIWOPt2tJUDYLja', NULL, NULL, 'damioja@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576356216, 1576356216, '08023214116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(40, 'Bola Ojalade', '6TV4sEab_pfIyKexQEy4Ei152hfIw1bu', '$2y$13$UkSTtt90QOTvII.IJ//xmuFpN8ZF7W7EWw/NvCxF5N/4mhURB8sQG', NULL, NULL, 'bola@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576356327, 1576356327, '08023460216', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(41, 'Tunde Ogilami', 'lVn2pygZ48Ac9zsqfvgoYrArJXorpCCR', '$2y$13$QkndzNuE8Zfg9pSTuUqy0uw.VbJGmWOXdvgZTqxJobD5CUxIgpYx.', NULL, NULL, 'tunogi@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576356427, 1576356427, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(42, 'Elizabeth Jajalun', '36RN-_C6rb4fehNmwEEwROHgPrz1JoCt', '$2y$13$nTuKIT4xNShIPC8tprCqEeDpAzUTo1OvSs/cco6GUFBuKYBb/5jsK', NULL, NULL, 'elija@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576356580, 1576356580, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(43, 'Olamide Falude', 'WjbEBRyvE9kITEW1SgU6j6lLdz_tFnm-', '$2y$13$7BIfWSG3oSb9u7ietKTNNO9t/lLWk/e2m1aVMh/JDV.e9.a9mI1m6', NULL, NULL, 'oulfai@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576356673, 1576356673, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(44, 'Deborah Odun', 'Hh3pLSlAgMvxJ-Kn99E6qQmbKyTt0uU-', '$2y$13$ihy0XNa1BV0Ej13IFhbIWeE4qh1QtRiBCc5lYufbxe1TrdhAzL0t2', NULL, NULL, 'debod@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576360806, 1576360806, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(45, 'Andela', 'CSFwi3xkG5EEaxkI3aO6mn7G6AQxHiyk', '$2y$13$7JI6Nb8Ds1oLS3pCBApgIuivocLIxaxfgx7k4H3vEGcRjlFLt8sgu', NULL, NULL, 'andela@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576361471, 1576361471, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'recruiter', NULL),
(46, 'Olatunji', 'a90PNgPbwQ8aE9wHEZ3GPheQnwOq2EKR', '$2y$13$giUrE0rM7Z0.6113SFECfOKIpADb6U7GKp8hB/MFZRTE6qKMGi0Vy', NULL, NULL, 'olatun@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576451794, 1576451794, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL),
(47, 'Tunde Majitofu', 'gRPy271sBJ8kuJkLyvEPSwltwruBaLo_', '$2y$13$qWZm91MhMD05Np0VjIodoOEHaVcGySGvy5ej0w9qnrlF5tK4AjA9O', NULL, NULL, 'tunnat@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 10, 1576451986, 1576451986, '08091760116', NULL, '0', NULL, NULL, NULL, NULL, NULL, NULL, 'talent', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `accounts`
--
ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `claims`
--
ALTER TABLE `claims`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mentor`
--
ALTER TABLE `mentor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `merchant`
--
ALTER TABLE `merchant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_page`
--
ALTER TABLE `payment_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payout`
--
ALTER TABLE `payout`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quotes`
--
ALTER TABLE `quotes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating`
--
ALTER TABLE `rating`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `referral`
--
ALTER TABLE `referral`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `request`
--
ALTER TABLE `request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `subscription`
--
ALTER TABLE `subscription`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `password_reset_token` (`password_reset_token`),
  ADD KEY `phone` (`phone`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `accounts`
--
ALTER TABLE `accounts`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `chat`
--
ALTER TABLE `chat`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `claims`
--
ALTER TABLE `claims`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `mentor`
--
ALTER TABLE `mentor`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `merchant`
--
ALTER TABLE `merchant`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `payment_page`
--
ALTER TABLE `payment_page`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `payout`
--
ALTER TABLE `payout`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=32;
--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `quotes`
--
ALTER TABLE `quotes`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rating`
--
ALTER TABLE `rating`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `referral`
--
ALTER TABLE `referral`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `request`
--
ALTER TABLE `request`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `subscription`
--
ALTER TABLE `subscription`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=58;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=48;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
